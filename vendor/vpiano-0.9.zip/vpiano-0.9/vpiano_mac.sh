#!/bin/sh
DYLD_LIBRARY_PATH=plugin demo/vpianodemo.app/Contents/MacOS/vpianodemo
