#!/bin/sh
LD_LIBRARY_PATH=plugin demo/vpianodemo
